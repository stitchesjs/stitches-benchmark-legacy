<a href="https://stitches-site.modulz-deploys.com" >
  <img width="149" alt="stitches" src="https://user-images.githubusercontent.com/372831/91163750-59a72880-e6ce-11ea-80b6-131a34da954c.png">
</a>

# The modern styling library.

Near-zero runtime, server-side rendering, multi-variant support, and best-in-class developer experience.

---

## Documentation

For full documentation, visit [stitches.dev](https://stitches.dev).

## Contributing

Not quite ready :)

## Authors

- Christian Alfoni ([@christianalfoni](https://twitter.com/christianalfoni)) - Codesandbox, Cerebral
- Pedro Duarte ([@peduarte](https://twitter.com/peduarte)) - [Modulz](https://modulz.app)
- Jenna Smith ([@jjenzz](https://twitter.com/jjenzz)) - [Modulz](https://modulz.app)
- Abdulhadi Alhallak ([@hadi_hlk](https://twitter.com/hadi_hlk)) - [Modulz](https://modulz.app)
- Fabrice Weinberg ([@fweinb](https://twitter.com/fweinb))

## License

Licensed under the MIT License, Copyright © 2020-present Modulz.

See [LICENSE](./LICENSE.md) for more information.
